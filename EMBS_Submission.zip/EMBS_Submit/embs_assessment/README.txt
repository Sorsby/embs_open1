code is in /src under question number folders.
ptolemy models are in /ptolemy_models

To run ptolemy in eclipse/intellij need to alter library paths to uni pc ptolemyII6.0.2 location.
Before running ptolemy sim for q2 check the N_MAX/MIN T_MAX/MIN vals.
Before loading onto mote change N_MAX/MIN T_MAX/MIN vals.